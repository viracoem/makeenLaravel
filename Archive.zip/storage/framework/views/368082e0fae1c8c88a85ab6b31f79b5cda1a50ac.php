Create User Form
<?php /**PATH /Users/mkvira/Documents/Projects/Laravel/example-app/resources/views/users/create.blade.php ENDPATH**/ ?>