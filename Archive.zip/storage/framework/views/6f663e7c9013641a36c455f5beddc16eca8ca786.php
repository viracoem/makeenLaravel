<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Product</title>
</head>

<body>
    <h1>Edit Product</h1>
    <form action="/products/edit/<?php echo e($product->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" value="<?php echo e($product->name); ?>"><br>
        <input type="number" name="amount" value="<?php echo e($product->amount); ?>"><br>
        <textarea name="description" cols="30" rows="10"><?php echo e($product->description); ?></textarea><br>
        <select name="color">
            <option value="red" <?php echo e($product->color == 'red' ? 'selected' : ''); ?>>red</option>
            <option value="blue" <?php echo e($product->color == 'blue' ? 'selected' : ''); ?>>blue</option>
        </select>
        <input type="submit" value="Send">
    </form>
</body>

</html>
<?php /**PATH /Users/mkvira/Documents/Projects/Laravel/example-app/resources/views/products/edit.blade.php ENDPATH**/ ?>