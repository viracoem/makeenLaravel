<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products List</title>
</head>

<body>
    <h1>Products List</h1>
    <table border="1" style="width:700px">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Amount</th>
            <th>Color</th>
            <th>manage</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->amount); ?></td>
                <td><?php echo e($product->color); ?></td>
                <td>
                    <a href="/products/edit/<?php echo e($product->id); ?>">Edit</a> /
                    <form action="/products/delete/<?php echo e($product->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="submit" value="Delete">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH /Users/mkvira/Documents/Projects/Laravel/example-app/resources/views/products/index.blade.php ENDPATH**/ ?>